# 📄 Arquivo: k_vigil_api/app.py

from flask import Flask, request, jsonify, render_template, redirect, send_from_directory
from flask_cors import CORS
from datetime import datetime
import os
import uuid
import json

# 🔧 Configuração inicial
app = Flask(__name__)
CORS(app)
UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 🧠 Banco de dados em memória
licencas = {}

# 📁 Caminho para arquivos persistentes (simples JSON)
DB_FILE = "db_licencas.json"
if os.path.exists(DB_FILE):
    with open(DB_FILE, "r") as f:
        licencas = json.load(f)

def salvar_licencas():
    with open(DB_FILE, "w") as f:
        json.dump(licencas, f, indent=2)

# 🔐 Rotas da API – Licenciamento

@app.route("/api/gerar", methods=["POST"])
def gerar_chave():
    data = request.get_json()
    uuid_valor = data.get("uuid") or str(uuid.uuid4())
    chave = f"KAIOS-{uuid_valor[:8]}-{str(uuid.uuid4())[:8]}"
    licencas[uuid_valor] = {
        "uuid": uuid_valor,
        "chave": chave,
        "ativa": True,
        "criada_em": datetime.now().isoformat()
    }
    salvar_licencas()
    return jsonify({"uuid": uuid_valor, "chave": chave})

@app.route("/api/licencas")
def listar_licencas():
    return jsonify(list(licencas.values()))

@app.route("/api/validar", methods=["POST"])
def validar_chave():
    data = request.get_json()
    uuid_valor = data.get("uuid")
    chave = data.get("chave")
    licenca = licencas.get(uuid_valor)
    valido = licenca and licenca["chave"] == chave and licenca["ativa"]
    return jsonify({"valido": bool(valido)})

@app.route("/api/regenerar", methods=["PATCH"])
def regenerar_chave():
    data = request.get_json()
    uuid_valor = data.get("uuid")
    if uuid_valor in licencas:
        nova_chave = f"KAIOS-{uuid_valor[:8]}-{str(uuid.uuid4())[:8]}"
        licencas[uuid_valor]["chave"] = nova_chave
        licencas[uuid_valor]["criada_em"] = datetime.now().isoformat()
        salvar_licencas()
    return "", 204

@app.route("/api/desativar", methods=["PATCH"])
def desativar_chave():
    data = request.get_json()
    uuid_valor = data.get("uuid")
    if uuid_valor in licencas:
        licencas[uuid_valor]["ativa"] = False
        salvar_licencas()
    return "", 204

@app.route("/api/excluir", methods=["DELETE"])
def excluir_chave():
    data = request.get_json()
    uuid_valor = data.get("uuid")
    if uuid_valor in licencas:
        del licencas[uuid_valor]
        salvar_licencas()
    return "", 204

# 🧩 Rotas do Painel HTML

@app.route("/")
@app.route("/painel")
def painel():
    arquivos = os.listdir(UPLOAD_FOLDER)
    return render_template("painel.html", arquivos=arquivos)

@app.route("/painel/upload", methods=["POST"])
def upload_arquivo():
    arquivo = request.files["arquivo"]
    caminho = os.path.join(UPLOAD_FOLDER, arquivo.filename)
    arquivo.save(caminho)
    return redirect("/painel")

@app.route("/painel/proteger", methods=["POST"])
def proteger_payload():
    uuid_valor = request.form["uuid_proteger"]
    nome_arquivo = request.form["arquivo_proteger"]
    caminho_original = os.path.join(UPLOAD_FOLDER, nome_arquivo)
    caminho_protegido = os.path.join(UPLOAD_FOLDER, f"{nome_arquivo}.kprotect")

    if not os.path.exists(caminho_original):
        return f"Arquivo {nome_arquivo} não encontrado", 404

    with open(caminho_original, "rb") as f_in, open(caminho_protegido, "wb") as f_out:
        dados = f_in.read()
        chave = licencas.get(uuid_valor, {}).get("chave", "").encode()
        if not chave:
            return "UUID inválido", 400
        f_out.write(bytes([b ^ chave[i % len(chave)] for i, b in enumerate(dados)]))

    return redirect("/painel")

@app.route("/painel/desproteger", methods=["POST"])
def desproteger_payload():
    uuid_valor = request.form["uuid_desproteger"]
    nome_arquivo = request.form["arquivo_desproteger"]
    caminho_cript = os.path.join(UPLOAD_FOLDER, nome_arquivo)
    caminho_descript = os.path.join(UPLOAD_FOLDER, nome_arquivo.replace(".kprotect", ".desprotegido"))

    if not os.path.exists(caminho_cript):
        return f"Arquivo {nome_arquivo} não encontrado", 404

    with open(caminho_cript, "rb") as f_in, open(caminho_descript, "wb") as f_out:
        dados = f_in.read()
        chave = licencas.get(uuid_valor, {}).get("chave", "").encode()
        if not chave:
            return "UUID inválido", 400
        f_out.write(bytes([b ^ chave[i % len(chave)] for i, b in enumerate(dados)]))

    return redirect("/painel")

@app.route("/uploads/<path:nome>")
def download_arquivo(nome):
    return send_from_directory(UPLOAD_FOLDER, nome, as_attachment=True)

# 🚀 Execução
if __name__ == "__main__":
    app.run(debug=True)
